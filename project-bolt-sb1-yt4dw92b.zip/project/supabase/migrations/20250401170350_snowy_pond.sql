/*
  # Create leads table for storing contact information

  1. New Tables
    - `leads`
      - `id` (uuid, primary key)
      - `email` (text, unique)
      - `phone_number` (text)
      - `created_at` (timestamp)
      
  2. Security
    - Enable RLS on `leads` table
    - Add policy for authenticated users to insert leads
    - Add policy for authenticated users to read their own leads
*/

CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  phone_number text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert leads"
  ON leads
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Authenticated users can read leads"
  ON leads
  FOR SELECT
  TO authenticated
  USING (true);
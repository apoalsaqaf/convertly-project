import React from 'react';
import { ArrowRight } from 'lucide-react';

const HomePage = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
      {/* Hero Section */}
      <div className="flex flex-col lg:flex-row items-center gap-12">
        <div className="flex-1 text-center lg:text-left">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-white mb-6 leading-tight">
            Turn Clicks into Customers with High-Converting Custom Landing Pages
          </h1>
          <p className="text-xl text-white/70 mb-8">
            Turn your website visitors into valuable leads with high-converting landing pages. 
            Boost your conversion rates and grow your business with data-driven design.
          </p>
          <button className="bg-gradient-to-r from-orange-400 to-orange-500 text-white px-8 py-4 rounded-lg font-medium hover:from-orange-500 hover:to-orange-600 transition-all duration-300 flex items-center gap-2 mx-auto lg:mx-0">
            Start Growing Now
            <ArrowRight size={20} />
          </button>
        </div>
        <div className="flex-1">
          <img
            src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=1920"
            alt="Business Growth Analytics"
            className="rounded-2xl shadow-2xl"
          />
        </div>
      </div>

      {/* Features Section */}
      <div className="mt-32">
        <h2 className="text-3xl font-bold text-white text-center mb-16">
          Why Choose Us
        </h2>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            'Data-Driven Design',
            'Conversion Optimization',
            'A/B Testing Analytics',
          ].map((feature, index) => (
            <div
              key={index}
              className="bg-white/5 backdrop-blur-lg rounded-xl p-6 hover:bg-white/10 transition-all duration-300"
            >
              <h3 className="text-xl font-semibold text-white mb-4">{feature}</h3>
              <p className="text-white/70">
                Leverage our expertise in conversion optimization to transform your landing pages into powerful lead generation tools.
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HomePage;
import React from 'react';

const AboutPage = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
      <div className="max-w-3xl mx-auto text-center">
        <h1 className="text-4xl font-bold text-white mb-8">About Us</h1>
        <p className="text-xl text-white/70 mb-12">
          At Convertly, we specialize in crafting high-converting, visually stunning landing pages 
          tailored to elevate your brand's online presence. Our mission is to empower businesses 
          by delivering customized solutions that not only captivate audiences but also drive 
          measurable results.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-12 items-center mt-20">
        <div>
          <img
            src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=800"
            alt="Team"
            className="rounded-2xl shadow-2xl"
          />
        </div>
        <div>
          <h2 className="text-3xl font-bold text-white mb-6">Our Mission</h2>
          <p className="text-white/70 mb-6">
            is to empower businesses by creating custom landing pages that effectively communicate 
            their brand message and drive measurable results. We are committed to delivering 
            high-quality, user-friendly designs that enhance online presence and support our 
            clients' marketing objectives.
          </p>
          <div className="grid grid-cols-2 gap-6">
            {[
              { label: 'Years Experience', value: '10+' },
              { label: 'Projects Completed', value: '200+' },
              { label: 'Team Members', value: '10+' },
              { label: 'Global Clients', value: '100+' },
            ].map((stat, index) => (
              <div
                key={index}
                className="bg-white/5 backdrop-blur-lg rounded-xl p-6 text-center"
              >
                <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
                <div className="text-white/70">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
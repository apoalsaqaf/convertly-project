import React, { useState } from 'react';
import { X } from 'lucide-react';

interface Project {
  title: string;
  description: string;
  image: string;
  category: {
    emoji: string;
    label: string;
  };
  metrics: {
    label: string;
    value: string;
  }[];
  fullDescription: string;
}

const projects: Project[] = [
  {
    title: 'E-commerce Landing Page',
    description: 'Boosted sales by 38% for a Shopify store using a holiday-themed lead gen page.',
    image: 'https://images.unsplash.com/photo-1607083206869-4c7672e72a8a?auto=format&fit=crop&q=80&w=800',
    category: {
      emoji: '🛒',
      label: 'E-Commerce'
    },
    metrics: [
      { label: 'Conversion Rate', value: '+38%' },
      { label: 'Revenue Increase', value: '+45%' },
      { label: 'Bounce Rate', value: '-28%' },
    ],
    fullDescription: 'Created a holiday-themed landing page for a Shopify store that significantly improved user engagement and sales. The page featured seasonal promotions, social proof, and urgency elements that drove conversions. Mobile-first design ensured seamless experience across all devices.',
  },
  {
    title: 'Real Estate Lead Page',
    description: 'Designed a hyper-local real estate lead funnel that converted at 3.5x the industry average.',
    image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&q=80&w=800',
    category: {
      emoji: '🏡',
      label: 'Real Estate'
    },
    metrics: [
      { label: 'Lead Generation', value: '+250%' },
      { label: 'Cost per Lead', value: '-40%' },
      { label: 'Engagement Rate', value: '+85%' },
    ],
    fullDescription: 'Developed a targeted landing page for real estate leads using hyper-local content and advanced form optimization. Implemented dynamic content based on visitor location and automated lead scoring to help prioritize high-value prospects.',
  },
  {
    title: 'Event Registration Page',
    description: 'Helped a virtual summit convert 22% more visitors into attendees with targeted A/B tested copy.',
    image: 'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?auto=format&fit=crop&q=80&w=800',
    category: {
      emoji: '🎤',
      label: 'Events'
    },
    metrics: [
      { label: 'Registration Rate', value: '+22%' },
      { label: 'Email Signups', value: '+35%' },
      { label: 'Return Visitors', value: '+40%' },
    ],
    fullDescription: 'Built a high-converting event registration page for a virtual summit using A/B tested copy and design elements. The page featured social proof, early-bird incentives, and a clear value proposition that resonated with the target audience.',
  },
];

const WorkPage = () => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
      <h1 className="text-4xl font-bold text-white mb-12 text-center">
        Our Work
      </h1>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {projects.map((project, index) => (
          <button
            key={index}
            onClick={() => setSelectedProject(project)}
            className="text-left bg-white/5 backdrop-blur-lg rounded-xl overflow-hidden 
                     hover:transform hover:scale-105 transition-all duration-300
                     hover:shadow-xl hover:shadow-white/10 group"
          >
            <div className="relative">
              <img
                src={project.image}
                alt={project.title}
                className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="absolute top-4 left-4 bg-black/30 backdrop-blur-sm px-3 py-1 rounded-full flex items-center gap-2">
                <span className="text-lg">{project.category.emoji}</span>
                <span className="text-white text-sm font-medium">{project.category.label}</span>
              </div>
            </div>
            <div className="p-6">
              <h3 className="text-xl font-semibold text-white mb-2">
                {project.title}
              </h3>
              <p className="text-white/70 mb-4">{project.description}</p>
              <div className="grid grid-cols-3 gap-2">
                {project.metrics.map((metric, idx) => (
                  <div key={idx} className="text-center p-2 bg-white/5 rounded-lg">
                    <div className="text-orange-400 font-bold">{metric.value}</div>
                    <div className="text-white/50 text-sm">{metric.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Case Study Modal */}
      {selectedProject && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-gradient-to-b from-gray-900 to-black rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="relative">
              <img
                src={selectedProject.image}
                alt={selectedProject.title}
                className="w-full h-64 object-cover rounded-t-2xl"
              />
              <div className="absolute top-4 left-4 bg-black/30 backdrop-blur-sm px-3 py-1 rounded-full flex items-center gap-2">
                <span className="text-lg">{selectedProject.category.emoji}</span>
                <span className="text-white text-sm font-medium">{selectedProject.category.label}</span>
              </div>
              <button
                onClick={() => setSelectedProject(null)}
                className="absolute top-4 right-4 bg-black/50 text-white p-2 rounded-full hover:bg-black/70 transition-colors"
              >
                <X size={24} />
              </button>
            </div>
            <div className="p-8">
              <h2 className="text-3xl font-bold text-white mb-4">{selectedProject.title}</h2>
              <p className="text-white/70 mb-8">{selectedProject.fullDescription}</p>
              
              <h3 className="text-xl font-semibold text-white mb-4">Key Metrics</h3>
              <div className="grid grid-cols-3 gap-4 mb-8">
                {selectedProject.metrics.map((metric, idx) => (
                  <div key={idx} className="bg-white/5 rounded-xl p-4 text-center">
                    <div className="text-2xl font-bold text-orange-400 mb-2">{metric.value}</div>
                    <div className="text-white/70">{metric.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WorkPage;
import React from 'react';
import { useState } from 'react';
import { Home, Briefcase, Users, Menu, X } from 'lucide-react';

import HomePage from './pages/HomePage';
import WorkPage from './pages/WorkPage';
import AboutPage from './pages/AboutPage';

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const NavButton = ({ page, icon: Icon, label }: { page: string; icon: React.ElementType; label: string }) => (
    <button
      onClick={() => {
        setCurrentPage(page);
        setIsMenuOpen(false);
      }}
      className={`flex items-center gap-2 px-6 py-3 rounded-lg transition-all duration-300 min-h-[48px] min-w-[48px] ${
        currentPage === page
          ? 'bg-white/10 text-white'
          : 'text-white/70 hover:text-white hover:bg-white/5'
      }`}
    >
      <Icon size={20} />
      <span className="font-medium">{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-teal-900 via-blue-900 to-blue-950">
      {/* Header Navigation */}
      <header className="fixed top-0 left-0 right-0 bg-black/30 backdrop-blur-md z-[100] shadow-lg">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center">
            <span className="text-2xl font-bold text-white select-none">CONVERTLY</span>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex gap-2">
            <NavButton page="home" icon={Home} label="Home" />
            <NavButton page="work" icon={Briefcase} label="Work" />
            <NavButton page="about" icon={Users} label="About Us" />
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-3 rounded-lg hover:bg-white/5 transition-colors min-h-[48px] min-w-[48px] active:bg-white/10"
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} className="text-white" /> : <Menu size={24} className="text-white" />}
          </button>
        </nav>

        {/* Mobile Navigation */}
        <div
          className={`md:hidden fixed inset-x-0 bg-black/95 backdrop-blur-md shadow-lg transition-all duration-300 ease-in-out ${
            isMenuOpen ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0'
          }`}
        >
          <div className="px-4 py-4 space-y-1">
            <NavButton page="home" icon={Home} label="Home" />
            <NavButton page="work" icon={Briefcase} label="Work" />
            <NavButton page="about" icon={Users} label="About Us" />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-16 min-h-screen">
        <div className="animate-fadeIn">
          {currentPage === 'home' && <HomePage />}
          {currentPage === 'work' && <WorkPage />}
          {currentPage === 'about' && <AboutPage />}
        </div>
      </main>
    </div>
  );
}

export default App;